var gOpen = "https://raw.githubusercontent.com/freemanbach/itec225/main/financedata/src/goog/goog_open_data_rev.csv" // github raw data
	
  Plotly.d3.csv(gOpen, function(err, rows){
    function unpack(rows, key) {
      return rows.map(function(row) { return row[key]; }); //menu functionality
    }
    
    var tracer = {
      type: "scatter",
      mode: "lines",
      name: 'Google Open',
      x: unpack(rows, 'date'),
      y: unpack(rows, 'open'),
      line: {color: '#14EDE7'} // unpacking raw date with coloration to the line graph 
    }
   
    var data = [tracer]; //packing 
    var layout = {
      title: {
        text : 'Googles Open Data '
      },
      xaxis: {
        title : {
         text : 'Dates' 
        }
      } ,
      yaxis : {
        title : {
          text : 'Open Price'
        }
      }
    };  //naming x, y axis, and title graph  
    Plotly.newPlot('gplot', data, layout); //packing up with id name
  })