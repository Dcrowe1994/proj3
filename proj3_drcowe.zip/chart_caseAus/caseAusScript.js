//var ausCase= "https://raw.githubusercontent.com/freemanbach/Python/master/python3/covid/worlddata/austria/ast_case_data.csv" //date used in the graph *not working on own needs work*
//var ausDeath= "https://raw.githubusercontent.com/freemanbach/Python/master/python3/covid/worlddata/austria/ast_death_data.csv" //second part of the data 

var caseDate = {
  x: [202008, 202009, 202010, 202011, 202012, 202101, 202102],
  y: [27438, 44813, 104925, 282456, 360815, 414398, 459440],
  mode: 'markers',
  name: 'Cases',
  text: ['August', 'September', 'October', 'November', 'December', 'January', 'February'],
  marker: {
    color: 'rgb(234, 153, 153)',
    size: 12
  },
  type: 'scatter'
};

var caseDeath = {
  x: [202008, 202009, 202010, 202011, 202012, 202101, 202102],
  y: [733, 799, 1109, 3184, 6222, 7721, 8561],
  mode: 'markers',
  name: 'Deaths',
  text: ['August', 'September', 'October', 'November', 'December', 'January', 'February'],
  marker: {
    color: 'rgb(142, 124, 195)',
    size: 12
  },
  type: 'scatter'
};

var data = [caseDate, caseDeath];

var layout = {
  title: 'Cases & Deaths in Austria (End of the Month 2020 - 2021)',
  xaxis: {
    title: 'Dates',
    showgrid: false,
    zeroline: false
  },
  yaxis: {
    title: 'Cases and Deaths',
    showline: false
  }
};

Plotly.newPlot('caseplot', data, layout);